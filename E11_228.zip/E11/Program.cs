﻿using System;
using System.IO;

/*                        __________
 *                       /         / 
 *                      /         /
 *                  R3 /   D3    /  R2
 *                    /         /
 *                   /         /
 *                  /_________/
 *                  |         |
 *              R6->|   D2    |
 *              _R5_|_________|
 *              |             |
 *              |             |  R3
 *              |             |
 *        R4    |     D1      |
 *              |             |
 *              |_____________|
 */

namespace E11
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;

            ////////////////////////////     INPUT     ///////////////////////////////
            // over-relaxation factor
            double omega = 1.73;
            // thermal boundary conditions
            double[] Rs = { 0.0, 0.0, 0.13, 0.13, 0.04, 0.10, 0.13, 0.13 };
            double[] Ts = { 0.0, 0.0, 20.0, 20.0, 0.00, 1.00, 1.00, 1.00 };

            // thermal conductivity
            double[] kx = { 0.770, 0.278, 0.130, 0.032, 0.025, 0.210, 0.210 };
            double[] ky = { 0.032, 0.025, 0.210, 0.13 };

            double k_mortar = 1.4;

            // region
            double dx = .002, dy = .002, dl = 0.003;      // grid interval

            double[] Xin = { 0.10, 0.05, 0.01, 0.14, 0.025, 0.038, 0.013, 0.68 };
            double[] Yin = { 0.17, 0.05, 0.013, 0.08, 0.92 };

            Exception_proc(Xin, Yin, kx, ky);
            /////////////////////////////////////////////////////////////////////
            //           _r means rectangle     domain(D1 and D2)
            //           _q means quadrilateral domain(D3)
            double[] x = new double[Xin.Length + 1]; Array.Clear(x, 0, x.Length);
            double[] y = new double[Yin.Length + 1]; Array.Clear(y, 0, y.Length);

            double[] xq = new double[Yin.Length + 1 - 2]; Array.Clear(xq, 0, xq.Length);
            double[] lq = new double[2];                  Array.Clear(lq, 0, lq.Length); 
            double alpa = 0;
            // making region
            make_region(Xin, Yin, x, y);
            alpa = getting_roofInformation(xq, lq, Xin, Yin);

            // mesh parameters
            double dxy = dx / dy, dyx = dy / dx;
            double dlcosa = dl * Math.Cos(alpa), dlsina = dl * Math.Sin(alpa);
            double dxdlcosa = dx * dlcosa, dxdlsina = dx * dlsina;
            double dlsina2dx = dlsina / dx, dxtga = dx * Math.Tan(alpa), tga = Math.Tan(alpa), tga4 = tga * 4, tga2 = tga * 2;

            int[] nkx   = new int[x.Length];
            int[] nky   = new int[y.Length];
            for (i = 0; i < x.Length; i++) nkx[i] = (int)(x[i] / dx + 0.0002);
            for (j = 0; j < y.Length; j++) nky[j] = (int)(y[j] / dy + 0.0002);

            int[] nkx_q = new int[xq.Length];
            int[] nkl_q = new int[lq.Length];
            for (i = 0; i < xq.Length; i++) nkx_q[i] = (int)(xq[i] / dx + 0.0002);
            for (j = 0; j < lq.Length; j++) nkl_q[j] = (int)(lq[j] / dl + 0.0002);

            int nkx1 = nkx[1], nkx7 = nkx[nkx.Length - 2], nky1 = nky[1], nky2 = nky[2];
            int nkxqL = nkx_q[nkx_q.Length - 1], nkyqL = nkl_q[nkl_q.Length - 1];
            // thermal value at boundaries
            double[] Q = new double[8]; Array.Clear(Q, 0, Q.Length); // the amount of heat

            // main variables
            double[,] Tr   = new double[nkx7, nky2 + 1]; Array.Clear(Tr, 0, Tr.Length);
            double[,] Tr_o = new double[nkx7, nky2 + 1]; Array.Clear(Tr_o, 0, Tr_o.Length);
            double[,] Kr   = new double[nkx7, nky2 + 1]; Array.Clear(Kr, 0, Kr.Length);

            double[,] Tq = new double[nkxqL, nkyqL + 2]; Array.Clear(Tq, 0, Tq.Length);
            double[,] Tq_o = new double[nkxqL, nkyqL + 2]; Array.Clear(Tq_o, 0, Tq_o.Length);
            double[,] Kq   = new double[nkxqL, nkyqL + 2]; Array.Clear(Kq, 0, Kq.Length);

            double[,] Tqx = new double[nkxqL, nkyqL + 2]; Array.Clear(Tqx, 0, Tqx.Length);
            double[,] Tqy = new double[nkxqL, nkyqL + 2]; Array.Clear(Tqy, 0, Tqy.Length);

            if (nkx7 - nkx1 != nkxqL)
            {
                TextWriter errorWriter = Console.Error;
                errorWriter.WriteLine("Both rectangle and quadrilateral regions are not matched.");

                return;
            }

            Console.WriteLine("Calculating Thermal conductivity, Kr..........");

            // producing region with property (Rectangle region)
            for (int ik = 0; ik < x.Length - 2; ik++) // in x - direction
            {
                if (ik == 0)
                    add_MAT_rectangle(Kr, kx[ik], x[ik], x[ik + 1], y[0], y[1], dx, dy);
                else
                    add_MAT_rectangle(Kr, kx[ik], x[ik], x[ik + 1], y[0], y[2], dx, dy);
            }

            add_MAT_rectangle(Kr, k_mortar, x[0], x[1], y[0] + 0.01, y[0] + 0.02, dx, dy); // mortar
            add_MAT_rectangle(Kr, k_mortar, x[0], x[1], y[0] + 0.25, y[0] + 0.26, dx, dy); // mortar
            add_MAT_rectangle(Kr, k_mortar, x[0], x[1], y[0] + 0.47, y[0] + 0.48, dx, dy); // mortar
            add_MAT_rectangle(Kr, k_mortar, x[0], x[1], y[0] + 0.69, y[0] + 0.70, dx, dy); // mortar
            add_MAT_rectangle(Kr, kx[2], x[0], x[2], y[1] + 0.01, y[1], dx, dy); // timber
            add_MAT_rectangle(Kr, kx[2], x[3], x[4], y[1], y[2], dx, dy); // timber
            add_MAT_rectangle(Kr, kx[2], x[1], x[2], y[1], y[1] + .04, dx, dy); // timber
            add_MAT_rectangle(Kr, kx[3], x[1], x[2], y[1] + .04, y[2], dx, dy); // removing timber

            // producing region with property (Quadrilateral region)
            for (int ik = 0; ik < xq.Length - 1; ik ++)
            {
                add_MAT_rectangle(Kq, ky[ik], xq[ik], xq[ik + 1], lq[0] + dl, lq[1] + dl, dx, dl);
            }

            // linking between both regions(D1, D2 & D3)
            for(i = 0; i < nkxqL; i ++)
            {
                Kr[i + nkx1, nky2] = Kq[i, 1];
                Kq[i, 0]           = Kr[i + nkx1, nky2 - 1];
                Kq[i, nkyqL + 1]   = Kq[i, nkyqL];
            }

            Console.WriteLine("Writing CSV files of K.........");
            StreamWriter file_Kr = new StreamWriter(@"..\Kr.csv");
            csvWriting(file_Kr, Kr);

            StreamWriter file_Kq = new StreamWriter(@"..\Kq.csv");
            csvWriting(file_Kq, Kq);

            // main solution
            Console.WriteLine("Iteraing.............");

            double err = 1e+20;
            int iter = 0;

            double bal = 1e+20, balTmp;
            while ((err > 1e-6) && (iter < 10000) && (bal > 0.000001))
            {
                iter++;
                double ce, cw, cn, cs, cne, cnw, cse, csw, cp, sr;

                // linking between both regions(D1, D2 & D3)
                for (i = 0; i < nkxqL; i++)
                {
                    Tr[i + nkx1, nky2] = Tq[i, 1];
                    Tq[i, 0] = Tr[i + nkx1, nky2 - 1];
                    Tq[i, nkyqL + 1] = Tq[i, nkyqL];
                }

                // ------------------------------------   Domain 1   ----------------
                ce = .5 * (Kr[0, 0] + Kr[1, 0]) * dyx + 0.5 * dy / Rs[4];
                cn = .5 * (Kr[0, 0] + Kr[0, 1]) * dxy;
                cp = ce + cn + 1 / Rs[4] * dy;
                sr = Ts[4] / Rs[4] * dy;

                Tr[0, 0] = (ce * Tr[1, 0] + cn * Tr[0, 1] + sr) / cp; // left -bottom

                for (i = 1; i < nkx7 - 1; i++)  // -  bottom adiabatic cell
                {
                    ce = .5 * (Kr[i, 0] + Kr[i + 1, 0]) * dyx;
                    cw = .5 * (Kr[i, 0] + Kr[i - 1, 0]) * dyx;
                    cn = .5 * (Kr[i, 0] + Kr[i, 1]) * dxy;
                    cp = ce + cw + cn;

                    Tr[i, 0] = (ce * Tr[i + 1, 0] + cw * Tr[i - 1, 0] + cn * Tr[i, 1]) / cp;
                }

                cw = .5 * (Kr[nkx7 - 1, 0] + Kr[nkx7 - 2, 0]) * dyx + .5 * dy / Rs[3];
                cn = .5 * (Kr[nkx7 - 1, 0] + Kr[nkx7 - 1, 1]) * dxy;
                cp = cw + cn + 1 / Rs[3] * dy;
                sr = Ts[3] / Rs[3] * dy;

                Tr[nkx7 - 1, 0] = (cw * Tr[nkx7 - 2, 0] + cn * Tr[nkx7 - 1, 1] + sr) / cp; // right- bottom

                for (j = 1; j < nky1; j++) // R3 boundary -right
                {
                    cw = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 2, j]) * dyx + .5 * dy / Rs[3];
                    cn = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 1, j + 1]) * dxy;
                    cs = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 1, j - 1]) * dxy;
                    cp = cw + cn + cs + 1 / Rs[3] * dy;
                    sr = Ts[3] / Rs[3] * dy;

                    Tr[nkx7 - 1, j] = (cw * Tr[nkx7 - 2, j] + cn * Tr[nkx7 - 1, j + 1] + cs * Tr[nkx7 - 1, j - 1] + sr) / cp;
                }

                for (j = 1; j < nky1 - 1; j++) // R4 boundary -left
                {
                    ce = .5 * (Kr[0, j] + Kr[1, j]) * dyx + .5 * dy / Rs[4];
                    cn = .5 * (Kr[0, j] + Kr[0, j + 1]) * dxy;
                    cs = .5 * (Kr[0, j] + Kr[0, j - 1]) * dxy;
                    cp = ce + cn + cs + 1 / Rs[4] * dy;
                    sr = Ts[4] / Rs[4] * dy;

                    Tr[0, j] = (ce * Tr[1, j] + cn * Tr[0, j + 1] + cs * Tr[0, j - 1] + sr) / cp;
                }

                for (i = 1; i < nkx7 - 1; i++) // interior
                    for (j = 1; j < nky1 - 1; j++)
                    {
                        ce = .5 * (Kr[i, j] + Kr[i + 1, j]) * dyx;
                        cw = .5 * (Kr[i, j] + Kr[i - 1, j]) * dyx;
                        cn = .5 * (Kr[i, j] + Kr[i, j + 1]) * dxy;
                        cs = .5 * (Kr[i, j] + Kr[i, j - 1]) * dxy;
                        cp = ce + cw + cn + cs;

                        Tr[i, j] = (ce * Tr[i + 1, j] + cw * Tr[i - 1, j] + cn * Tr[i, j + 1] + cs * Tr[i, j - 1]) / cp;
                        Tr[i, j] = omega * Tr[i, j] + (1 - omega) * Tr_o[i, j];
                    }

                ce = .5 * (Kr[0, nky1 - 1] + Kr[1, nky1 - 1]) * dyx + .5 * dy / Rs[4];
                cs = .5 * (Kr[0, nky1 - 1] + Kr[0, nky1 - 2]) * dxy + .5 * dx / Rs[5];
                cp = ce + cs + 1 / Rs[4] * dy + 1 / Rs[5] * dx;
                sr = Ts[4] / Rs[4] * dy + Ts[5] / Rs[5] * dx;

                Tr[0, nky1 - 1] = (ce * Tr[1, nky1 - 1] + cs * Tr[0, nky1 - 2] + sr) / cp;

                for (i = 1; i < nkx1; i++) // R5 boundary
                {
                    ce = .5 * (Kr[i, nky1 - 1] + Kr[i + 1, nky1 - 1]) * dyx;
                    cw = .5 * (Kr[i, nky1 - 1] + Kr[i - 1, nky1 - 1]) * dyx;
                    cs = .5 * (Kr[i, nky1 - 1] + Kr[i, nky1 - 2]) * dxy + .5 * dx / Rs[5];
                    cp = ce + cw + cs + 1 / Rs[5] * dx;
                    sr = Ts[5] / Rs[5] * dx;

                    Tr[i, nky1 - 1] = (ce * Tr[i + 1, nky1 - 1] + cw * Tr[i - 1, nky1 - 1] + cs * Tr[i, nky1 - 2] + sr) / cp;
                }

                // ======================        interface between D1 and D2      ===============================
                for (i = nkx1; i < nkx7 - 1; i++) 
                {
                    ce = .5 * (Kr[i, nky1 - 1] + Kr[i + 1, nky1 - 1]) * dyx;
                    cw = .5 * (Kr[i, nky1 - 1] + Kr[i - 1, nky1 - 1]) * dyx;
                    cn = .5 * (Kr[i, nky1 - 1] + Kr[i, nky1]) * dxy;
                    cs = .5 * (Kr[i, nky1 - 1] + Kr[i, nky1 - 2]) * dxy;
                    cp = ce + cw + cn + cs;

                    Tr[i, nky1 - 1] = (ce * Tr[i + 1, nky1 - 1] + cw * Tr[i - 1, nky1 - 1] + cn * Tr[i, nky1] + cs * Tr[i, nky1 - 2]) / cp;
                    Tr[i, nky1 - 1] = omega * Tr[i, nky1 - 1] + (1 - omega) * Tr_o[i, nky1 - 1];
                }

                // ======================                D2                 ------------------------------------------
                for (j = nky1; j < nky2; j++) // R6 boundary - left
                {
                    ce = .5 * (Kr[nkx1, j] + Kr[nkx1 + 1, j]) * dyx + .5 * dy / Rs[6];
                    cn = .5 * (Kr[nkx1, j] + Kr[nkx1, j + 1]) * dxy;
                    cs = .5 * (Kr[nkx1, j] + Kr[nkx1, j - 1]) * dxy;
                    cp = ce + cn + cs + 1 / Rs[6] * dy;
                    sr = Ts[6] / Rs[6] * dy;

                    Tr[nkx1, j] = (ce * Tr[nkx1 + 1, j] + cn * Tr[nkx1, j + 1] + cs * Tr[nkx1, j - 1] + sr) / cp;
                }

                for (j = nky1; j < nky2; j++) // R3 boundary - right
                {
                    cw = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 2, j]) * dyx + .5 * dy / Rs[3];
                    cn = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 1, j + 1]) * dxy;
                    cs = .5 * (Kr[nkx7 - 1, j] + Kr[nkx7 - 1, j - 1]) * dxy;
                    cp = cw + cn + cs + 1 / Rs[3] * dy;
                    sr = Ts[3] / Rs[3] * dy;

                    Tr[nkx7 - 1, j] = (cw * Tr[nkx7 - 2, j] + cn * Tr[nkx7 - 1, j + 1] + cs * Tr[nkx7 - 1, j - 1] + sr) / cp;
                }

                for (i = nkx1 + 1; i < nkx7 - 1; i++) // interior
                    for (j = nky1; j < nky2; j++)
                    {
                        ce = .5 * (Kr[i, j] + Kr[i + 1, j]) * dyx;
                        cw = .5 * (Kr[i, j] + Kr[i - 1, j]) * dyx;
                        cn = .5 * (Kr[i, j] + Kr[i, j + 1]) * dxy;
                        cs = .5 * (Kr[i, j] + Kr[i, j - 1]) * dxy;
                        cp = ce + cw + cn + cs;

                        Tr[i, j] = (ce * Tr[i + 1, j] + cw * Tr[i - 1, j] + cn * Tr[i, j + 1] + cs * Tr[i, j - 1]) / cp;
                        Tr[i, j] = omega * Tr[i, j] + (1 - omega) * Tr_o[i, j];
                    }

                // ======================         D3 - Quadrilateral          ------------------------------------------
                double ke, kw, kn, ks;
                dxdlsina = dl;
                i = 0;
                for (j = 1; j < nkyqL + 1; j ++) // R7 boundary - top
                {
                    ke = .5 * (Kq[i, j] + Kq[i + 1, j]);
                    kn = .5 * (Kq[i, j] + Kq[i, j + 1]);
                    ks = .5 * (Kq[i, j] + Kq[i, j - 1]);

                    ce = ke * (dlsina2dx + dlcosa / dxtga) - (kn - ks) / tga2;
                    cn = -ke / tga4 + kn * (dx / dlsina + 1 / tga2);
                    cs =  ke / tga4 + ks * (dx / dlsina - 1 / tga2);
                    cp = ce + cn + cs;

                    cne = -(ke + 2 * kn) / tga4;
                    cse =  (ke + 2 * ks) / tga4;

                    ce += dl / 2 / Rs[7];
                    cp += 3 * dl / 2 / Rs[7];
                    sr = Ts[7] / Rs[7] * dl;

                    Tq[i, j]  = (ce * Tq[i + 1, j] + cn * Tq[i, j + 1] + cs * Tq[i, j - 1]) / cp;
                    Tq[i, j] += (cne * Tq[i + 1, j + 1] + cse * Tq[i + 1, j - 1] + sr) / cp;
                }

                i = nkxqL - 1;
                for (j = 1; j < nkyqL + 1; j++) // R2 boundary - bottom
                {
                    kw = .5 * (Kq[i, j] + Kq[i - 1, j]);
                    kn = .5 * (Kq[i, j] + Kq[i, j + 1]);
                    ks = .5 * (Kq[i, j] + Kq[i, j - 1]);

                    cw =  kw * (dlsina2dx + dlcosa / dxtga) - (kn - ks) / tga2;
                    cn =  kw / tga4 + kn * (dx / dlsina - 1 / tga2);
                    cs = -kw / tga4 + ks * (dx / dlsina + 1 / tga2);
                    cp =  cw + cn + cs;

                    cnw =  (kw + 2 * kn) / tga4;
                    csw = -(kw + 2 * ks) / tga4;

                    cw += dl / 2 / Rs[2];
                    cp += 3 * dl / 2 / Rs[2];
                    sr = Ts[2] / Rs[2] * dl;

                    Tq[i, j] = (cw * Tq[i - 1, j] + cn * Tq[i, j + 1] + cs * Tq[i, j - 1]) / cp;
                    Tq[i, j] += (cnw * Tq[i - 1, j + 1] + csw * Tq[i - 1, j - 1] + sr) / cp;
                }

                j = nkyqL;
                for (i = 1; i < nkxqL - 1; i++)
                {
                    ke = .5 * (Kq[i, j] + Kq[i + 1, j]);
                    kw = .5 * (Kq[i, j] + Kq[i - 1, j]);
                    ks = .5 * (Kq[i, j] + Kq[i, j - 1]);

                    ce = ke * (dlsina2dx + dlcosa / dxtga - 1 / tga4) + ks / tga4;
                    cw = kw * (dlsina2dx + dlcosa / dxtga + 1 / tga4) - ks / tga4;
                    cs = ks * dx / dlsina + (ke - kw) / tga4;
                    cse = (ke + ks) / tga4;
                    csw = -(kw + ks) / tga4;

                    cp = ce + cw + cs + cse + csw;

                    Tq[i, j] = (ce * Tq[i + 1, j] + cw * Tq[i - 1, j] + cs * Tq[i, j - 1]) / cp;
                    Tq[i, j] += (cse * Tq[i + 1, j - 1] + csw * Tq[i - 1, j - 1]) / cp;
                }

                for (i = 1; i < nkxqL - 1; i++)
                    for (j = 1; j < nkyqL + 1; j++)
                    {
                        ke = .5 * (Kq[i, j] + Kq[i + 1, j]);
                        kw = .5 * (Kq[i, j] + Kq[i - 1, j]);
                        kn = .5 * (Kq[i, j] + Kq[i, j + 1]);
                        ks = .5 * (Kq[i, j] + Kq[i, j - 1]);

                        ce = ke * (dlsina2dx + dlcosa / dxtga) - (kn - ks) / tga4;
                        cw = kw * (dlsina2dx + dlcosa / dxtga) + (kn - ks) / tga4;
                        cn = kn * dx / dlsina - (ke - kw) / tga4;
                        cs = ks * dx / dlsina + (ke - kw) / tga4;
                        cp = ce + cw + cn + cs;

                        cne = -(ke + kn) / tga4;
                        cnw =  (kw + kn) / tga4;
                        cse =  (ke + ks) / tga4;
                        csw = -(kw + ks) / tga4;

                        Tq[i, j]  = (ce * Tq[i + 1, j] + cw * Tq[i - 1, j] + cn * Tq[i, j + 1] + cs * Tq[i, j - 1]) / cp;
                        Tq[i, j] += (cne * Tq[i + 1, j + 1] + cnw * Tq[i - 1, j + 1] + cse * Tq[i + 1, j - 1] + csw * Tq[i - 1, j - 1]) / cp;
                        Tq[i, j]  = omega * Tq[i, j] + (1 - omega) * Tq_o[i, j];
                    }

                ///////////////////////////////////   POST-PROCESSING   //////////////////////////////////////
                err = -1e+20;
                for (i = 0; i < nkx7; i++)
                {
                    for (j = 0; j < nky2; j++)
                    {
                        if (Math.Abs(Tr_o[i, j] - Tr[i, j]) > err)
                            err = Math.Abs(Tr_o[i, j] - Tr[i, j]);
                    }
                }

                for (i = 0; i < nkxqL; i++)
                {
                    for (j = 0; j < nkyqL; j++)
                    {
                        if (Math.Abs(Tq_o[i, j] - Tq[i, j]) > err)
                            err = Math.Abs(Tq_o[i, j] - Tq[i, j]);
                    }
                }

                for (i = 0; i < nkx7; i++)
                {
                    for (j = 0; j < nky2; j++)
                    {
                        Tr_o[i, j] = Tr[i, j];
                    }
                }

                for (i = 0; i < nkxqL ; i++)
                {
                    for (j = 0; j < nkyqL + 2; j++)
                    {
                        Tq_o[i, j] = Tq[i, j];
                    }
                }
                
                Array.Clear(Q, 0, Q.Length);
                for (j = 0; j < nky2; j++)
                    Q[3] += (Ts[3] - (3 * Tr[nkx7 - 1, j] - Tr[nkx7 - 2, j]) / 2) / Rs[3] * dy;

                for (j = 0; j < nky1; j++)
                    Q[4] += (Ts[4] - (3 * Tr[0, j] - Tr[1, j]) / 2) / Rs[4] * dy;

                for (i = 0; i < nkx1; i++)
                    Q[5] += (Ts[5] - (3 * Tr[i, nky1 - 1] - Tr[i, nky1 - 2]) / 2) / Rs[5] * dx;

                for (j = nky1; j < nky2; j++)
                    Q[6] += (Ts[6] - (3 * Tr[nkx1, j] - Tr[nkx1 + 1, j]) / 2) / Rs[6] * dy;

                for (j = 1; j < nkyqL; j++)
                {
                    Q[2] += (Ts[2] - (3 * Tq[nkxqL - 1, j] - Tq[nkxqL - 2, j]) / 2) / Rs[2] * dl;
                    Q[7] += (Ts[7] - (3 * Tq[0, j] - Tq[1, j]) / 2) / Rs[7] * dl;
                }

                bal = 0;
                balTmp = 0;
                for (i = 2; i < 8; i++)
                {
                    bal += Q[i];
                    balTmp += Math.Abs(Q[i]) / 2;
                }

                bal = bal / balTmp;

                if (iter % 100 == 0)
                    Console.WriteLine(iter.ToString() + "-th error = " + err.ToString("0.0000000") + "; balance = " + bal.ToString("0.00000"));
            }


            Console.WriteLine("Writing Temperature field.........");
            StreamWriter file_Tr = new StreamWriter(@"..\Tr.csv");
            csvWriting(file_Tr, Tr);

            StreamWriter file_Tq = new StreamWriter(@"..\Tq.csv");
            csvWriting(file_Tq, Tq);

            Console.WriteLine("-------  Post-processed results  -------------");
            Console.WriteLine("Q2 = " + Q[2].ToString("0.00000"));
            Console.WriteLine("Q3 = " + Q[3].ToString("0.00000"));
            Console.WriteLine("Q4 = " + Q[4].ToString("0.00000"));
            Console.WriteLine("Q5 = " + Q[5].ToString("0.00000"));
            Console.WriteLine("Q6 = " + Q[6].ToString("0.00000"));
            Console.WriteLine("Q7 = " + Q[7].ToString("0.00000"));

            Console.WriteLine("-------  Summation  -------------");
            double Qp = Q[2] + Q[3] + Q[5];
            double Qm = Q[4] + Q[6] + Q[7];
            Console.WriteLine("Q+ = " + Qp.ToString("0.00000"));
            Console.WriteLine("Q- = " + Qm.ToString("0.00000"));

            Console.WriteLine("'Q+' + 'Q-' = " + (Qp + Qm).ToString("0.00000"));
            Console.WriteLine("balance = " + bal.ToString("0.0000000"));
            Console.WriteLine("error   = " + err.ToString("0.0000000"));

            Console.WriteLine("-------  simulation completed -------------");
        }

        static void Exception_proc(double[] Xin, double[] Yin, double[] kx, double[] ky)
        {
            if (Xin.Length - kx.Length != 1)
            {
                TextWriter errorWriter = Console.Error;
                errorWriter.WriteLine("Xin and kx are not matched.");

                return;
            }

            if (Yin.Length - ky.Length != 1)
            {
                TextWriter errorWriter = Console.Error;
                errorWriter.WriteLine("Yin and ky are not matched.");

                return;
            }
        }
        static double getting_roofInformation(double[] xq, double[] yq, double[] Xin, double[] Yin)
        {
            int i;
            double alpa;
            double roof_thick = 0, wall_thick = 0;
            for (i = 0; i < Yin.Length - 2; i++)
                roof_thick += Yin[i];
            for (i = 1; i < Xin.Length - 1; i++)
                wall_thick += Xin[i];

            alpa = Math.Asin(roof_thick / wall_thick);

            xq[0] = 0;
            for (i = 0; i < Yin.Length - 2; i++)
                xq[i + 1] = xq[i] + Yin[i] / Math.Sin(alpa); //  Yin.Length - 3 - 

            yq[0] = 0;
            yq[1] = Xin[Xin.Length - 1] / Math.Cos(alpa);

            return alpa;
        }
        static void add_MAT_rectangle(double[,] K, double k_add, double xs, double xe, double ys, double ye, double dx, double dy)
        {
            int nxs, nxe, nys, nye;

            if (ys > ye)
            {
                double tmp = ye;    ye = ys;    ys = tmp;
            }

            nxs = (int)((xs + 0.02 * dx) / dx);
            nxe = (int)((xe + 0.02 * dx) / dx);
            nys = (int)((ys + 0.02 * dy) / dy);
            nye = (int)((ye + 0.02 * dy) / dy);

            for (int j = nys; j < nye; j++)
                for (int i = nxs; i < nxe; i++)
                {
                    K[i, j] = k_add;
                }
        }

        static void invert(double[] Var)
        {
            double[] tmp = new double[Var.Length];

            for (int i = 0; i < Var.Length; i++)
                tmp[i] = Var[Var.Length - i - 1];

            for (int i = 0; i < Var.Length; i++)
                Var[i] = tmp[i];
        }

        static void make_region(double[] Xin, double[] Yin, double[] xr, double[] yr)
        {
            int i;
            xr[0] = 0;
            for (i = 0; i < Xin.Length; i++)
                xr[i + 1] = xr[i] + Xin[i];

            yr[0] = 0;
            for (i = 0; i < Yin.Length - 2; i++)
                yr[i + 1] = yr[i] + Yin[Yin.Length - i - 1];
            //y[i + 1] = y[i] + Yin[i];
        }

        static void csvWriting(StreamWriter file, double[,] K)
        {
            int nx = K.GetLength(0), ny = K.GetLength(1);

            for (int i = 0; i < nx; i++)
            {
                string content = "";
                for (int j = 0; j < ny; j++)
                {
                    content += K[i, j].ToString("0.000") + ",";
                }
                file.WriteLine(content);
            }
        }
    }
}
